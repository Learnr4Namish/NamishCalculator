# NamishCalculator
<p>The calculator app built for both linux and windows with <b>C++</b></p>